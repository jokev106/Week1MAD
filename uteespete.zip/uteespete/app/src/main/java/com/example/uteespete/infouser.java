package com.example.uteespete;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toolbar;

import com.example.uteespete.model.User;


public class infouser extends AppCompatActivity {
    public static final String EXTRA_EDIT="extra";
    private User user;
    Button edit, delete;
    TextView nama, alamat, umur;
    Toolbar backbtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_infouser);

        if (getIntent().getParcelableExtra(EXTRA_EDIT)!= null){
            user = getIntent().getParcelableExtra(EXTRA_EDIT);
        }

        nama = findViewById(R.id.txt_nama);
        alamat = findViewById(R.id.txt_alamat);
        umur  = findViewById(R.id.txt_umur);

        nama.setText(user.getNama());
        alamat.setText(user.getAlamat());
        umur.setText(user.getUmur());

        edit = findViewById(R.id.button_edit);
        delete = findViewById(R.id.button_delete);
        backbtn = findViewById(R.id.tooladd);


    }
}
