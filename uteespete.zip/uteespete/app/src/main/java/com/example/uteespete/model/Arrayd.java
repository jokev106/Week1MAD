package com.example.uteespete.model;

import java.util.ArrayList;

public class Arrayd {
    public static
    ArrayList<User> dataa = new ArrayList<>();

}
